<?php
// periksa apakah user sudah login, cek kehadiran session name
// jika tidak ada, redirect ke login.php
// session_start();
// if (!isset($_SESSION["nama"])) {
//     header("Location: login.php");
// }

// buka koneksi dengan MySQL
include("connection.php");

// cek apakah form telah di submit
if (isset($_POST["submit"])) {
    // form telah disubmit, cek apakah berasal dari edit_mahasiswa.php
    // atau update data dari form_edit.php

    if ($_POST["submit"] == "Edit") {
        //nilai form berasal dari halaman edit_mahasiswa.php

        // ambil nilai nim
        $id = htmlentities(strip_tags(trim($_POST["id"])));
        // filter data
        $id = mysqli_real_escape_string($link, $id);

        // ambil semua data dari database untuk menjadi nilai awal form
        $query = "SELECT * FROM pariwisata WHERE id='$id'";
        $result = mysqli_query($link, $query);

        if (!$result) {
            die("Query Error: " . mysqli_errno($link) .
                " - " . mysqli_error($link));
        }

        // tidak perlu pakai perulangan while, karena hanya ada 1 record
        $data = mysqli_fetch_assoc($result);

        $id_kecamatan    = $data["id_kecamatan"];
        $wisata          = $data["wisata"];
        $tanggal         = $data["tanggal"];
        $isi             = $data["isi"];
        $gambar          = $data["gambar"];

        // untuk tanggal harus dipecah
        $tgl = substr($data["tanggal"], 8, 2);
        $bln = substr($data["tanggal"], 5, 2);
        $thn = substr($data["tanggal"], 0, 4);

        // bebaskan memory
        mysqli_free_result($result);
    } else if ($_POST["submit"] == "Update Data") {
        // nilai form berasal dari halaman form_edit.php
        // ambil semua nilai form
        $id           = htmlentities(strip_tags(trim($_POST["id"])));
        $id_kecamatan = htmlentities(strip_tags(trim($_POST["id_kecamatan"])));
        $wisata       = htmlentities(strip_tags(trim($_POST["wisata"])));
        $isi          = htmlentities(strip_tags(trim($_POST["isi"])));
        $gambar       = htmlentities(strip_tags(trim($_POST["gambar"])));
        $tgl          = htmlentities(strip_tags(trim($_POST["tgl"])));
        $bln          = htmlentities(strip_tags(trim($_POST["bln"])));
        $thn          = htmlentities(strip_tags(trim($_POST["thn"])));
    }

    // proses validasi form
    // siapkan variabel untuk menampung pesan error
    $pesan_error = "";

    // cek apakah "nim" sudah diisi atau tidak
    if (empty($id)) {
        $pesan_error .= "id belum diisi <br>";
    }
    // NIM harus angka dengan 8 digit
    elseif (!preg_match("/^[0-9]{8}$/", $id)) {
        $pesan_error .= "id harus berupa 6 digit angka <br>";
    }

    // cek apakah "nama" sudah diisi atau tidak
    if (empty($id_kecamatan)) {
        $pesan_error .= "id_kecamatan belum diisi <br>";
    }

    // cek apakah "tempat lahir" sudah diisi atau tidak
    if (empty($wisata)) {
        $pesan_error .= "wisata belum diisi <br>";
    }

    // cek apakah "jurusan" sudah diisi atau tidak
    if (empty($isi)) {
        $pesan_error .= "keterngan belum diisi <br>";
    }

    // IPK harus berupa angka dan tidak boleh negatif
    if (empty($gambar)) {
        $pesan_error .= "gambar belum diisi <br>";
    }

    // jika tidak ada error, input ke database
    if (($pesan_error === "") and ($_POST["submit"] == "Update Data")) {

        // buka koneksi dengan MySQL
        include("connection.php");

        // filter semua data
        $id             = mysqli_real_escape_string($link, $id);
        $id_kecamatan   = mysqli_real_escape_string($link, $id_kecamatan);
        $wisata         = mysqli_real_escape_string($link, $wisata);
        $isi            = mysqli_real_escape_string($link, $isi);
        $gambar         = mysqli_real_escape_string($link, $gambar);
        $tgl            = mysqli_real_escape_string($link, $tgl);
        $bln            = mysqli_real_escape_string($link, $bln);
        $thn            = mysqli_real_escape_string($link, $thn);
        //gabungkan format tanggal agar sesuai dengan date MySQL
        $tgl = $thn . "-" . $bln . "-" . $tgl;

        //buat dan jalankan query UPDATE
        $query  = "UPDATE pariwisata SET ";
        $query .= "id = '$id', id_kecamatan = '$id_kecamatan', wisata = '$wisata', ";
        $query .= "tanggal = '$tgl', isi='$isi', gambar='$gambar'";
        $query .= "WHERE id = '$id'";

        $result = mysqli_query($link, $query);

        //periksa hasil query
        if ($result) {
            // INSERT berhasil, redirect ke tampil_mahasiswa.php + pesan
            $pesan = "pariwisata dengan id_kecamatan = \"<b>$id_kecamatan</b>\" sudah berhasil di update";
            $pesan = urlencode($pesan);
            header("Location: tampil_pariwisata.php?pesan={$pesan}");
        } else {
            die("Query gagal dijalankan: " . mysqli_errno($link) .
                " - " . mysqli_error($link));
        }
    }
} else {
    // form diakses secara langsung!
    // redirect ke edit_mahasiswa.php
    header("Location: edit_pariwisata.php");
}

// siapkan array untuk nama bulan
$arr_bln = array(
    "1" => "Januari",
    "2" => "Februari",
    "3" => "Maret",
    "4" => "April",
    "5" => "Mei",
    "6" => "Juni",
    "7" => "Juli",
    "8" => "Agustus",
    "9" => "September",
    "10" => "Oktober",
    "11" => "Nopember",
    "12" => "Desember"
);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Edit Pariwisata Malang</title>
    <link href="style1.css" rel="stylesheet">
    <link rel="icon" href="favicon.png" type="image/png">
</head>

<body>
    <div class="container">
        <div id="header">
            <h1 id="logo">Edit Pariwisata <span>Malang</span></h1>
            <p id="tanggal"><?php echo date("d M Y"); ?></p>
        </div>
        <hr>
        <nav>
            <ul>
                <li><a href="tampil_pariwisata.php">Tampil</a></li>
                <li><a href="tambah_priwisata.php">Tambah</a>
                <li><a href="edit_pariwisata.php">Edit</a>
                <li><a href="hapus_paiwisata.php">Hapus</a></li>
                <li><a href="logout.php">Logout</a>
            </ul>
        </nav>
        <form id="search" action="tampil_pariwisata.php" method="get">
            <p>
                <label for="id">ID : </label>
                <input type="text" name="id" id="id" placeholder="search...">
                <input type="submit" name="submit" value="Search">
            </p>
        </form>
        <h2>Edit Data Pariwisata</h2>
        <?php
        // tampilkan error jika ada
        if ($pesan_error !== "") {
            echo "<div class=\"error\">$pesan_error</div>";
        }
        ?>
        <form id="form_pariwisata" action="edit_wisata.php" method="post">
            <fieldset>
                <legend>pariwisata</legend>
                <p>
                    <label for="nim">ID : </label>
                    <input type="text" name="id" id="id" value="<?php echo $id ?>" placeholder="Contoh: 12345678">
                    (8 digit angka)
                </p>
                <p>
                    <label for="id_kecamatan">ID KECAMATAN : </label>
                    <input type="text" name="id_kecamatan" id="id_kecamatan" value="<?php echo $id_kecamatan ?>">
                </p>
                <p>
                    <label for="wisata">WISATA : </label>
                    <input type="text" name="wisata" id="wisata" value="<?php echo $wisata ?>">
                </p>
                <p>
                    <label for="tgl">Tanggal: </label>
                    <select name="tgl" id="tgl">
                        <?php
                        for ($i = 1; $i <= 31; $i++) {
                            if ($i == $tgl) {
                                echo "<option value = $i selected>";
                            } else {
                                echo "<option value = $i >";
                            }
                            echo str_pad($i, 2, "0", STR_PAD_LEFT);
                            echo "</option>";
                        }
                        ?>
                    </select>
                    <select name="bln">
                        <?php
                        foreach ($arr_bln as $key => $value) {
                            if ($key == $bln) {
                                echo "<option value=\"{$key}\" selected>{$value}</option>";
                            } else {
                                echo "<option value=\"{$key}\">{$value}</option>";
                            }
                        }
                        ?>
                    </select>
                    <select name="thn">
                        <?php
                        for ($i = 1925; $i <= 2021; $i++) {
                            if ($i == $thn) {
                                echo "<option value = $i selected>";
                            } else {
                                echo "<option value = $i >";
                            }
                            echo "$i </option>";
                        }
                        ?>
                    </select>
                </p>
                <p>
                    <label for="isi">ISI : </label>
                    <input type="text" name="isi" id="isi" value="<?php echo $isi ?>">
                </p>
                <p>
                    <label for="gambar">GAMBAR : </label>
                    <input type="file" name="gambar" id="gambar" value="<?php echo $gambar ?>">

                </p>

            </fieldset>
            <br>
            <p>
                <input type="submit" name="submit" value="Update Data">
            </p>
        </form>

    </div>

</body>

</html>
<?php
// tutup koneksi dengan database mysql
mysqli_close($link);
?>