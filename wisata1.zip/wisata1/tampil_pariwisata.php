<?php
// periksa apakah user sudah login, cek kehadiran session name 
// jika tidak ada, redirect ke login.php
session_start();
if (!isset($_SESSION["nama"])) {
    header("Location: login.php");
}

// buka koneksi dengan MySQL
include("connection.php");

// ambil pesan jika ada  
if (isset($_GET["pesan"])) {
    $pesan = $_GET["pesan"];
}

// cek apakah form telah di submit
// berasal dari form pencairan, siapkan query 
if (isset($_GET["submit"])) {

    // ambil nilai nama
    $id = htmlentities(strip_tags(trim($_GET["id"])));

    // filter untuk $nama untuk mencegah sql injection
    $id = mysqli_real_escape_string($link, $id);

    // buat query pencarian
    $query  = "SELECT * FROM pariwisata WHERE id LIKE '%$id%' ";
    $query .= "ORDER BY id ASC";

    // buat pesan
    $pesan = "Hasil pencarian untuk id <b>\"$id\" </b>:";
} else {
    // bukan dari form pencairan
    // siapkan query untuk menampilkan seluruh data dari tabel mahasiswa
    $query = "SELECT * FROM pariwisata ORDER BY id ASC";
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>DATA PARIWISATA</title>
    <link href="style1.css" rel="stylesheet">
    <link rel="icon" href="favicon.png" type="image/png">
</head>

<body>
    <div class="container">
        <div id="header">
            <h1 id="logo">Pariwisata <span>Malang</span></h1>
            <p id="tanggal"><?php echo date("d M Y"); ?></p>
        </div>
        <hr>
        <nav>
            <ul>
                <li><a href="tampil_pariwisata.php">Tampil</a></li>
                <li><a href="tambah_pariwisata.php">Tambah</a>
                <li><a href="edit_wisata.php">Edit</a>
                <li><a href="hapus_pariwisata.php">Hapus</a></li>
                <li><a href="logout.php">Logout</a>
            </ul>
        </nav>
        <form id="search" action="tampil_pariwisata.php" method="get">
            <p>
                <label for="id">ID : </label>
                <input type="text" name="id" id="id" placeholder="search...">
                <input type="submit" name="submit" value="Search">
            </p>
        </form>
        <h2>Data Pariwisata</h2>
        <?php
        // tampilkan pesan jika ada
        if (isset($pesan)) {
            echo "<div class=\"pesan\">$pesan</div>";
        }
        ?>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>ID KECAMATAN</th>
                <th>WISATA</th>
                <th>Tanggal</th>
                <th>ISI</th>
                <th>GAMBAR</th>
            </tr>
            <?php
            // jalankan query
            $result = mysqli_query($link, $query);

            if (!$result) {
                die("Query Error: " . mysqli_errno($link) .
                    " - " . mysqli_error($link));
            }

            //buat perulangan untuk element tabel dari data mahasiswa
            while ($data = mysqli_fetch_assoc($result)) {
                // konversi date MySQL (yyyy-mm-dd) menjadi dd-mm-yyyy
                $tanggal_php = strtotime($data["tanggal"]);
                $tanggal = date("d - m - Y", $tanggal_php);

                echo "<tr>";
                echo "<td>$data[id]</td>";
                echo "<td>$data[id_kecamatan]</td>";
                echo "<td>$data[wisata]</td>";
                echo "<td>$tanggal</td>";
                echo "<td>$data[isi]</td>";
                echo "<td>$data[gambar]</td>";
                echo "</tr>";
            }

            // bebaskan memory 
            mysqli_free_result($result);

            // tutup koneksi dengan database mysql
            mysqli_close($link);
            ?>
        </table>
        <div id="footer">
            Copyright © <?php echo date("Y"); ?> Codelearn
        </div>
    </div>
</body>

</html>