<?php
// periksa apakah user sudah login, cek kehadiran session name
// jika tidak ada, redirect ke login.php
session_start();
if (!isset($_SESSION["nama"])) {
    header("Location: login.php");
}

// buka koneksi dengan MySQL
include("connection.php");
?>
<!DOCTYPE html>
<!-- Created By CodingNepal - www.codingnepalweb.com -->
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Responsive Mega Menu | CodingNepal</title> -->
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Langar&display=swap" rel="stylesheet">

<body>
    <nav>
        <div class="wrapper">
            <div class="logo"><a href="#">Disparpora Kab Magelang</a></div>
            <input type="radio" name="slider" id="menu-btn">
            <input type="radio" name="slider" id="close-btn">
            <ul class="nav-links">
                <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
                <li><a href="#">Beranda</a></li>
                <li><a href="#">Download</a>
                    <ul class="drop-menu">
                        <li><a href="#">Data Pemprov</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="desktop-item">Profil</a>
                    <input type="checkbox" id="showDrop">
                    <label for="showDrop" class="mobile-item">Profil</label>
                    <ul class="drop-menu">
                        <li><a href="#">Alamat Lenkap</a></li>
                        <li><a href="#">Daftar Pejabat</a></li>
                        <li><a href="#">Struktur Organisasi</a></li>
                        <li><a href="#">Tugas Dan Fungsi</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="desktop-item">Mega Menu</a>
                    <input type="checkbox" id="showMega">
                    <label for="showMega" class="mobile-item">Mega Menu</label>
                    <div class="mega-box">
                        <div class="content">
                            <div class="row">
                                <header>PPID</header>
                                <ul class="mega-links">
                                    <li><a href="#">Daftar Informasi Publik</a></li>
                                    <li><a href="#">Informasi Berkala</a></li>
                                    <li><a href="#">Informasi Serta Merta</a></li>
                                    <li><a href="#">Informasi Setiap Saat</a></li>
                                    <li><a href="#">Informasi Yang Dikecualikan</a></li>
                                </ul>
                            </div>
                            <div class="row">
                                <header>Layanan</header>
                                <ul class="mega-links">
                                    <li><a href="#">Desa Wisata</a></li>
                                    <li><a href="#">Wisata Alam</a></li>
                                    <li><a href="#">Wisata Buatan</a></li>
                                    <li><a href="#">Wisata Budaya</a></li>
                                    <li><a href="#">Wisata Kerajinan</a></li>
                                    <li><a href="#">Wisata Kuliner</a></li>
                                    <li><a href="#">Wisata Minat Khusus</a></li>
                                    <li><a href="#">Wisata Religi</a></li>
                                </ul>
                            </div>
                            <div class="row">
                                <header>Berita</header>
                                <ul class="mega-links">
                                    <li><a href="#">Artikel</a></li>
                                    <li><a href="#">Berita Utama</a></li>
                                    <li><a href="#">Pers Rilis</a></li>
                                </ul>
                            </div>
                            <div class="row">
                                <header>Tentang</header>
                                <ul class="mega-links">
                                    <li><a href="#">Destinasi</a></li>
                                    <li><a href="#">Kepemudaan</a></li>
                                    <li><a href="#">Olahraga</a></li>
                                    <li><a href="#">Promosi</a></li>
                                    <li><a href="#">Sejarah</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
                <li><a href="tampil_pariwisata.php">Tambah Pariwisata</a></li>
            </ul>
            <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
        </div>
    </nav>
    <input type="radio" id="trigger1" name="slider">
    <label for="trigger1"></label>
    <div class="slide bg1"></div>

    <input type="radio" id="trigger2" name="slider" checked autofocus>
    <label for="trigger2"></label>
    <div class="slide bg2"></div>

    <input type="radio" id="trigger3" name="slider">
    <label for="trigger3"></label>
    <div class="slide bg3"></div>
    <div class="body-text">
        <div class="title">
            <h1>MAGELANG</h1>
            <h2>Disparpora Kab Magelang</h2>
        </div>
</body>


</html>