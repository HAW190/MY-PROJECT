<?php
// periksa apakah user sudah login, cek kehadiran session name
// jika tidak ada, redirect ke login.php
// session_start();
// if (!isset($_SESSION["nama"])) {
//   header("Location: login.php");
// }

// buka koneksi dengan MySQL
include("connection.php");

// cek apakah form telah di submit (untuk menghapus data)
if (isset($_POST["submit"])) {
  // form telah disubmit, proses data

  // ambil nilai nim
  $id = htmlentities(strip_tags(trim($_POST["id"])));
  // filter data
  $id = mysqli_real_escape_string($link, $id);

  //jalankan query DELETE
  $query = "DELETE FROM pariwisata WHERE id='$id' ";
  $hasil_query = mysqli_query($link, $query);

  //periksa query, tampilkan pesan kesalahan jika gagal
  if ($hasil_query) {
    // DELETE berhasil, redirect ke tampil_mahasiswa.php + pesan
    $pesan = "Pariwisata dengan id = \"<b>$id</b>\" sudah berhasil di hapus";
    $pesan = urlencode($pesan);
    header("Location: tampil_pariwisata.php?pesan={$pesan}");
  } else {
    die("Query gagal dijalankan: " . mysqli_errno($link) .
      " - " . mysqli_error($link));
  }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Hapus Priwisata Magelang</title>
  <link href="style1.css" rel="stylesheet">
  <link rel="icon" href="favicon.png" type="image/png">
</head>

<body>
  <div class="container">
    <div id="header">
      <h1 id="logo">Hapus Pariwisata <span>Malang</span></h1>
      <p id="tanggal"><?php echo date("d M Y"); ?></p>
    </div>
    <hr>
    <nav>
      <ul>
        <li><a href="tampil_pariwisata.php">Tampil</a></li>
        <li><a href="tambah_pariwisata.php">Tambah</a>
        <li><a href="edit_pariwisata.php">Edit</a>
        <li><a href="hapus_pariwista.php">Hapus</a></li>
        <li><a href="logout.php">Logout</a>
      </ul>
    </nav>
    <form id="search" action="tampil_pariwisata.php" method="get">
      <p>
        <label for="id">ID : </label>
        <input type="text" name="nama" id="nama" placeholder="search...">
        <input type="submit" name="submit" value="Search">
      </p>
    </form>
    <h2>Hapus Data pariwisata</h2>
    <?php
    // tampilkan pesan jika ada
    if ((isset($_GET["pesan"]))) {
      echo "<div class=\"pesan\">{$_GET["pesan"]}</div>";
    }
    ?>
    <table border="1">
      <tr>
        <th>ID</th>
        <th>ID KECAMATAN</th>
        <th>WISATA</th>
        <th>Tanggal</th>
        <th>ISI</th>
        <th>GAMBAR</th>
        <th></th>
      </tr>
      <?php
      // buat query untuk menampilkan seluruh data tabel mahasiswa
      $query = "SELECT * FROM pariwisata ORDER BY id ASC";
      $result = mysqli_query($link, $query);

      if (!$result) {
        die("Query Error: " . mysqli_errno($link) .
          " - " . mysqli_error($link));
      }

      //buat perulangan untuk element tabel dari data mahasiswa
      while ($data = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>$data[id]</td>";
        echo "<td>$data[id_kecamatan]</td>";
        echo "<td>$data[wisata]</td>";
        echo "<td>$data[tanggal]</td>";
        echo "<td>$data[isi]</td>";
        echo "<td>$data[gambar]</td>";
        echo "<td>";
      ?>
        <form action="hapus_pariwisata.php" method="post">
          <input type="hidden" name="id" value="<?php echo "$data[id]"; ?>">
          <input type="submit" name="submit" value="Hapus">
        </form>
      <?php
        echo "</td>";
        echo "</tr>";
      }

      // bebaskan memory
      mysqli_free_result($result);

      // tutup koneksi dengan database mysql
      mysqli_close($link);
      ?>
    </table>
    <div id="footer">
      Copyright © <?php echo date("Y"); ?> Codelearn
    </div>
  </div>
</body>

</html>