<?php
// buat koneksi dengan database mysql
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$link   = mysqli_connect($dbhost, $dbuser, $dbpass);

//periksa koneksi, tampilkan pesan kesalahan jika gagal
if (!$link) {
    die("Koneksi dengan database gagal: " . mysqli_connect_errno() .
        " - " . mysqli_connect_error());
}

//buat database kampusku jika belum ada
$query = "CREATE DATABASE IF NOT EXISTS magelang";
$result = mysqli_query($link, $query);

if (!$result) {
    die("Query Error: " . mysqli_errno($link) .
        " - " . mysqli_error($link));
} else {
    echo "Database <b>'magelang'</b> berhasil dibuat... <br>";
}

//pilih database kampusku
$result = mysqli_select_db($link, "magelang");

if (!$result) {
    die("Query Error: " . mysqli_errno($link) .
        " - " . mysqli_error($link));
} else {
    echo "Database <b>'magelang'</b> berhasil dipilih... <br>";
}

//   // cek apakah tabel mahasiswa sudah ada. jika ada, hapus tabel
//   $query = "DROP TABLE IF EXISTS mahasiswa";
//   $hasil_query = mysqli_query($link, $query);

//   if(!$hasil_query){
//     die ("Query Error: ".mysqli_errno($link).
//          " - ".mysqli_error($link));
//   }
//   else {
//     echo "Tabel <b>'mahasiswa'</b> berhasil dihapus... <br>";
//   }

// buat query untuk CREATE tabel mahasiswa
$query  = "CREATE TABLE pariwisata (id VARCHAR(20), id_kecamatan VARCHAR(20), ";
$query .= "wisata VARCHAR(900), tanggal DATE, ";
$query .= "isi TEXT(1000), gambar VARCHAR(50),PRIMARY KEY (id))";

$hasil_query = mysqli_query($link, $query);

if (!$hasil_query) {
    die("Query Error: " . mysqli_errno($link) .
        " - " . mysqli_error($link));
} else {
    echo "Tabel <b>'pariwisata'</b> berhasil dibuat... <br>";
}

// buat query untuk INSERT data ke tabel mahasiswa
$query  = "INSERT INTO pariwisata VALUES ";
$query .= "('1405011', '03079', 'Taman Panggoda', '2020-12-23', ";
$query .= "'Tak perlu risau berwisata  ke Kabupaten Magelang  karena selalu uptadate , Sudah bukan hal yang asing lagi kalau Magelang memiliki wisata alam yang begitu beragam. Magelang salalu bermunculan Daya Tarik Wisata baru yang pasti kekinian . Taman Bunga Pagoda. Mungkin di pemikiran kita pasti bangunan (tempat Ibadah) tapi ini berbeda adanya Pagoda yang di tengah-tengah hamparan bunga- Bunga Celosia yang warna-warni. Pagoda yang berdiri kokoh menjulang setinggi 12 meter dan terdiri dari tiga lantai ini selain untuk spot foto juga sebagai tempat untuk melihat area taman dan pemandangan sekitarnya dari atas menikmati keindahan alam yang masih alami serta ber swa foto hitz dan kekininan berkonsep wisata outdoor seperti taman bunga, wisata edukasi, taman kelinci, mandi bola, air mancur, wahana air, waterball, panahan, floatish angsa mengelilingi kolam serta  gazebo- gazebo . Untuk harga tiket masuk Taman Bunga Pagoda yaitu sebesar 10rb per orang, dengan jam buka operasional standar dari jam 08.00 WIB pagi hingga jam 17.00 WIB Daya Tarik Wisata ini  berada di Desa Candirejo, Ketangi, Kaliangkrik, Kabupaten Magelang. Taman Pagoda bisa menjadi alternatif mengisi liburan kamu di  Kabupaten Magelang. selamat liburan', 'S2.jpg'), ";
$query .= "('1502104', '03080', 'Wisata alam Gunung Gupak', '2020-12-23', ";
$query .= "'Segera hadir  wisata baru di  Kabupaten Magelang berada ditengah- tengah lereng Gunung Merapi dan Gunung  Merbabu .Daya Tarik  Wisata  (DTW)  buatan ini tidak jauh dari DTW Ketep Pass.  DTW  ini dinamai “Wisata alam Gunung Gupak” berlokasi di Dusun Gondangan Tengah Desa Wulung Gunung Kecamatan Sawangan Kabupaten Magelang.Daya Tarik Wisata ini (DTW) sebuah taman yang dengan pemandangan alam pegunungan yang masih alami yang dapat melihat 7 (tujuh ) Gunung sekaligus Merapi, Merbabu, Sumbing, Andong, Telomoyo, Sindoro, Prau, dan Menoreh . tak hanya pemandangan alamnya . disini menyuguhkan berbagai spot instagenic untuk  mendapatkan foto yang keren-keren. Beberapa fasilitas tersedia gazebo ,petik strawbery, saung-saung istirahat,area camping ground, outbound dan sarana pendukung lainnya. Di gardu pandang atau menara yang  bisa melihat pemandangan alam yang berada di sekitar lereng Merbabu Merapi. Salah satu spot yang menjadi icon di Daya Tarik Wisata Ini patung angsa yang cukup besar ( angsa bertelur ) dalam bahasa jawa angkrem.', 'gupak.jpg'), ";
$query .= "('1503036', '03081', 'Pemandian Air hangat Candi Umbul', '2020-12-23', ";
$query .= "'Berbeda dari candi-candi lain, Candi Umbuk begitu special dan unik. Dari dasar candi ini muncul  gelembung-gelembung  air Langat yang di percaya mampu menjaga agar awet muda serta dapat menyembuhkan berbagai penyakit kulit. Yang paling unik air panasnya tak berbau belereng seperti sumber air pans lainnya sehingga pengunjung dapat berpuas-puas berendam sambil menikmati udara sejuk. Keseluruhan dinding klam terbuat dari lapisan batu andesit (batu candi ). Konon menurut legenda  kolam ini menjadi  pempat pemandian para bangsawan . sejumlahbatuan situs berjejer ditepi kolam , seakan menggambarkan berbagai relief bentuk tumbuhan, binatang dan stupa. Dibeberapa titik sekitaran candi umbul ada bererapa petilasan berbentuk lingga dan zoni membuktikan candi umbul merupakan candi yang bercorak hindu dan diperkirakan dibangun pada masa Dinsty Sanjaya', 'umbul.jpg'), ";
$query .= "('1502032', '03082', 'Ladon Little Island', '2020-12-23', ";
$query .= "'Berlibur ke Kabupaten Magelang wajib menjelajahi keindahan alamnya. Alam masih alami dengan dilelilingi  Gunung-Gunung menjadikan hawa di Kabupaten Magelang sejuk. Destinasi wisata baru hadir di Kabupaten Magelang, .Namanya Ladon Little Island. Berlokasi tak jauh dari Candi Borobudur, destinasi di pinggir Sungai Progo itu menyuguhkan pesona alam ala-ala  pantai berpasir putih di Dusun Sangen, Desa Candirejo, Kecamatan Borobudur. Ladon Little Island merupakan pinggiran aliran Sungai Progo dengan keunikan adanya pasir yang berwarna putih bantaran sungai  yang menyerupai dengan pasir ala-ala  di pantai yang masih alami dan bersih. Kita dapat berswa foto di  bantaran sungai latar pemandangan hijaunya lereng perbukitan Menoreh.pasir di bantaran sungai merupakan ladhu atau material dari  letusan Gunung Merapi yang terbentuk puluha tahunnya terbentuk yang menjadikan ala-ala pasir pantai', 'london.jpg'), ";
$query .= "('1301212', '03083', 'Mangli Sky View “ Wisata Menembus Awan “', '2020-12-23', ";
$query .= "'Mendengar Mangli  bayangan kita daerah diujung Kabupaten Magelang lereng Gunung Sumbing . Mangli Sky View  di ketinggian 1.570 timur Gunung Sumbing tepatntya Desa Mangli, Kecamatan kaliangkrik.   Udara yang dingin dengan hawa pegunungan, hamparan awan sepanjang mata memandang .Bagi pecinta sunrise  tempat ini sangat rekomendet dengan view  9 Gunung sebagai background, seperti  Gunung  Merapi , Gunung Merbabu Gunung, Andong,  Gunung Telomoyo, Gunung Tidar , Gunung Giyanti, Gunung Ungaran, Pegunungan Menoreh dan yang pasti  kemegahan Gunung Sumbing . Tak hanya Pemandangan alam , Mangli Sky View  menyajikan Hamparan kebun Sayuran berpadu dengan kicau burung  terbang bebas dialam . Bagi yang mau menginap  terdapat  Camping Ground yg aman dan nyaman dengan fasilitas yang cukup memadai   (Listrik, WIFI, Mushola dan Air yang masih seger ). Mangli Sky View  Daya Tarik Wisata Kabupaten Magelang yang cocok untuk menikmati alam Pegunungan

','sky.jpg')";

$hasil_query = mysqli_query($link, $query);

if (!$hasil_query) {
    die("Query Error: " . mysqli_errno($link) .
        " - " . mysqli_error($link));
} else {
    echo "Tabel <b>'pariwisata'</b> berhasil diisi... <br>";
}

// cek apakah tabel admin sudah ada. jika ada, hapus tabel
$query = "DROP TABLE IF EXISTS admin";
$hasil_query = mysqli_query($link, $query);

if (!$hasil_query) {
    die("Query Error: " . mysqli_errno($link) .
        " - " . mysqli_error($link));
} else {
    echo "Tabel <b>'admin'</b> berhasil dihapus... <br>";
}

// buat query untuk CREATE tabel admin
$query  = "CREATE TABLE admin (username VARCHAR(50), password CHAR(40))";
$hasil_query = mysqli_query($link, $query);

if (!$hasil_query) {
    die("Query Error: " . mysqli_errno($link) .
        " - " . mysqli_error($link));
} else {
    echo "Tabel <b>'admin'</b> berhasil dibuat... <br>";
}

// buat username dan password untuk admin
$username = "admin";
$password = sha1("rahasia123");

// buat query untuk INSERT data ke tabel admin
$query  = "INSERT INTO admin VALUES ('$username','$password')";

$hasil_query = mysqli_query($link, $query);

if (!$hasil_query) {
    die("Query Error: " . mysqli_errno($link) .
        " - " . mysqli_error($link));
} else {
    echo "Tabel <b>'admin'</b> berhasil diisi... <br>";
}

// tutup koneksi dengan database mysql
mysqli_close($link);
