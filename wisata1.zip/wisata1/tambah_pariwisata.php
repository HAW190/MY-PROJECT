<?php
// periksa apakah user sudah login, cek kehadiran session name
// jika tidak ada, redirect ke login.php
// session_start();
// if (!isset($_SESSION["id"])) {
//     header("Location: tambah_pariwisata.php");
// }

// buka koneksi dengan MySQL
include("connection.php");

// cek apakah form telah di submit
if (isset($_POST["submit"])) {
    // form telah disubmit, proses data

    // ambil semua nilai form
    $id                   = htmlentities(strip_tags(trim($_POST["id"])));
    $id_kecamatan         = htmlentities(strip_tags(trim($_POST["id_kecamatan"])));
    $wisata               = htmlentities(strip_tags(trim($_POST["wisata"])));
    $isi                  = htmlentities(strip_tags(trim($_POST["isi"])));
    $gambar               = htmlentities(strip_tags(trim($_POST["gambar"])));
    $tgl                  = htmlentities(strip_tags(trim($_POST["tgl"])));
    $bln                  = htmlentities(strip_tags(trim($_POST["bln"])));
    $thn                  = htmlentities(strip_tags(trim($_POST["thn"])));

    // siapkan variabel untuk menampung pesan error
    $pesan_error = "";

    // cek apakah "nim" sudah diisi atau tidak
    if (empty($id)) {
        $pesan_error .= "ID belum diisi <br>";
    }
    // NIM harus angka dengan 8 digit
    elseif (!preg_match("/^[0-9]{8}$/", $id)) {
        $pesan_error .= "ID harus berupa 8 digit angka <br>";
    }

    // cek ke database, apakah sudah ada nomor NIM yang sama
    // filter data $nim
    $nim = mysqli_real_escape_string($link, $id);
    $query = "SELECT * FROM pariwisata WHERE id='$id'";
    $hasil_query = mysqli_query($link, $query);

    // cek jumlah record (baris), jika ada, $nim tidak bisa diproses
    $jumlah_data = mysqli_num_rows($hasil_query);
    if ($jumlah_data >= 1) {
        $pesan_error .= "ID yang sama sudah digunakan <br>";
    }

    // cek apakah "nama" sudah diisi atau tidak
    if (empty($id_kecamatan)) {
        $pesan_error .= "ID KECAMATAN belum diisi <br>";
    }

    // cek apakah "tempat lahir" sudah diisi atau tidak
    if (empty($wisata)) {
        $pesan_error .= "WISATA belum diisi <br>";
    }

    // cek apakah "jurusan" sudah diisi atau tidak
    if (empty($isi)) {
        $pesan_error .= "Keterangan belum diisi <br>";
    }
    // jika tidak ada error, input ke database
    if ($pesan_error === "") {

        // filter semua data
        $id             = mysqli_real_escape_string($link, $id);
        $id_kecamatan   = mysqli_real_escape_string($link, $id_kecamatan);
        $wisata         = mysqli_real_escape_string($link, $wisata);
        $isi            = mysqli_real_escape_string($link, $isi);
        $gambar         = mysqli_real_escape_string($link, $gambar);
        $tgl            = mysqli_real_escape_string($link, $tgl);
        $bln            = mysqli_real_escape_string($link, $bln);
        $thn            = mysqli_real_escape_string($link, $thn);

        //gabungkan format tanggal agar sesuai dengan date MySQL
        $tgl_lhr = $thn . "-" . $bln . "-" . $tgl;

        //buat dan jalankan query INSERT
        $query = "INSERT INTO pariwisata VALUES ";
        $query .= "('$id', '$id_kecamatan', '$wisata', ";
        $query .= "'$tgl','$isi','$gambar')";

        $result = mysqli_query($link, $query);

        //periksa hasil query
        if ($result) {
            // INSERT berhasil, redirect ke tampil_mahasiswa.php + pesan
            $pesan = "Pariwisata dengan id = \"<b>$id</b>\" sudah berhasil di tambah";
            $pesan = urlencode($pesan);
            header("Location: tampil_pariwisata.php?pesan={$pesan}");
        } else {
            die("Query gagal dijalankan: " . mysqli_errno($link) .
                " - " . mysqli_error($link));
        }
    }
} else {
    // form belum disubmit atau halaman ini tampil untuk pertama kali
    // berikan nilai awal untuk semua isian form
    $pesan_error       = "";
    $id                = "";
    $id_kecamatan      = "";
    $wisata            = "";
    $isi               = "";
    $gambar            = "";
    $tgl               = 1;
    $bln               = "1";
    $thn               = 1925;
}

// siapkan array untuk nama bulan
$arr_bln = array(
    "1" => "Januari",
    "2" => "Februari",
    "3" => "Maret",
    "4" => "April",
    "5" => "Mei",
    "6" => "Juni",
    "7" => "Juli",
    "8" => "Agustus",
    "9" => "September",
    "10" => "Oktober",
    "11" => "Nopember",
    "12" => "Desember"
);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Pariwisata Magelang</title>
    <link href="style1.css" rel="stylesheet">
    <link rel="icon" href="favicon.png" type="image/png">
</head>

<body>
    <div class="container">
        <div id="header">
            <h1 id="logo">Tambah Pariwisata <span>Malang</span></h1>
            <p id="tanggal"><?php echo date("d M Y"); ?></p>
        </div>
        <hr>
        <nav>
            <ul>
                <li><a href="tampil_pariwisata.php">Tampil</a></li>
                <li><a href="tambah_pariwisata.php">Tambah</a>
                <li><a href="edit_pariwisata.php">Edit</a>
                <li><a href="hapus_pariwisata.php">Hapus</a></li>
                <li><a href="logout.php">Logout</a>
            </ul>
        </nav>
        <form id="search" action="tampil_pariwisata.php" method="get">
            <p>
                <label for="id">wisata : </label>
                <input type="text" name="nama" id="nama" placeholder="search...">
                <input type="submit" name="submit" value="Search">
            </p>
        </form>
        <h2>Tambah Data Pariwisata</h2>
        <?php
        // tampilkan error jika ada
        if ($pesan_error !== "") {
            echo "<div class=\"error\">$pesan_error</div>";
        }
        ?>
        <form id="form_pariwisata" action="tambah_pariwisata.php" method="post">
            <fieldset>
                <legend>pariwisata</legend>
                <p>
                    <label for="nim">ID : </label>
                    <input type="text" name="id" id="id" value="<?php echo $id ?>" placeholder="Contoh: 12345678">
                    (8 digit angka)
                </p>
                <p>
                    <label for="id_kecamatan">ID KECAMATAN : </label>
                    <input type="text" name="id_kecamatan" id="id_kecamatan" value="<?php echo $id_kecamatan ?>">
                </p>
                <p>
                    <label for="wisata">WISATA : </label>
                    <input type="text" name="wisata" id="wisata" value="<?php echo $wisata ?>">
                </p>
                <p>
                    <label for="tgl">Tanggal: </label>
                    <select name="tgl" id="tgl">
                        <?php
                        for ($i = 1; $i <= 31; $i++) {
                            if ($i == $tgl) {
                                echo "<option value = $i selected>";
                            } else {
                                echo "<option value = $i >";
                            }
                            echo str_pad($i, 2, "0", STR_PAD_LEFT);
                            echo "</option>";
                        }
                        ?>
                    </select>
                    <select name="bln">
                        <?php
                        foreach ($arr_bln as $key => $value) {
                            if ($key == $bln) {
                                echo "<option value=\"{$key}\" selected>{$value}</option>";
                            } else {
                                echo "<option value=\"{$key}\">{$value}</option>";
                            }
                        }
                        ?>
                    </select>
                    <select name="thn">
                        <?php
                        for ($i = 1990; $i <= 2005; $i++) {
                            if ($i == $thn) {
                                echo "<option value = $i selected>";
                            } else {
                                echo "<option value = $i >";
                            }
                            echo "$i </option>";
                        }
                        ?>
                    </select>
                </p>
                <p>
                    <label for="isi">ISI : </label>
                    <input type="text" name="isi" id="isi" value="<?php echo $isi ?>">
                </p>
                <p>
                    <label for="gambar">GAMBAR : </label>
                    <input type="file" name="gambar" id="gambar" value="<?php echo $gambar ?>">

                </p>

            </fieldset>
            <br>
            <p>
                <input type="submit" name="submit" value="Tambah Data">
            </p>
        </form>

        <div id="footer">
            Copyright © <?php echo date("Y"); ?> Codelearn
        </div>

    </div>

</body>

</html>
<?php
// tutup koneksi dengan database mysql
mysqli_close($link);
?>